# check qcc_figures.r in directory tests/
