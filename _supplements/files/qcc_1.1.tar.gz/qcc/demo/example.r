## example.r

library(qcc)
data(data.Y63)

str(data.Y63)
  
system.time(QCC.Y63 <- scat.plot.quantization(data=data.Y63,nbin=100)) # 30 seconds for 0.5M

## save(data.Y63, QCC.Y63, file="QCC.Y63.RData")
## load(file="QCC.Y63.RData")

str(  QCC.Y63)
  
## pdf("Fig.QCC.Y63.pdf", width=12, height=6)
##postscript("Fig.QCC.Y63.eps", width=12, height=6)
junk <- scat.plot.quantization(data=data.Y63,QCC=QCC.Y63)
## dev.off()

