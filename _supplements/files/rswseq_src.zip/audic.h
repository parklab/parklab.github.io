double audic_pmf(long y, long x, long T, long N);
double audic_sig(long y, long x, long T, long N);
