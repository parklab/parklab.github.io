#include <math.h>
#include <stdlib.h>

/* Return random variable in [0, 1) */
double
runif()
{
	return drand48();
}

/* Return a random variable with distn Exp(mu) */
double
rexp(double mu)
{
	return -log(1.0 - runif()) / mu;
}

/* Return a random variable with distn Pois(lambda) */
int
rpois(double lambda)
{
	int i;
	double x, mu;

	mu = 1.0/lambda;

	x = 0;
	for (i = 0; x <= 1.0; ++i)
		x += rexp(mu);

	return (i - 1) > 0 ? i - 1 : 0;
}
