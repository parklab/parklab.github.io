#ifndef __RANDOM_H__
#define __RANDOM_H__

double runif();
double rexp(double mu);
int rpois(double lambda);

#endif
