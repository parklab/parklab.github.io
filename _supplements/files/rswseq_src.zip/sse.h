typedef int v4si __attribute__((vector_size(4*sizeof(int))));
typedef int v2si __attribute__((vector_size(2*sizeof(int))));

typedef float v4sf __attribute__((vector_size(4*sizeof(float))));
