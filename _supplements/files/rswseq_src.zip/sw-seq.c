/*
 * NOTES:
 *   - Tae-min's perl script ignores regions with no reads,
 *     effectively setting every read as a neighbor to the
 *     other.  This program retains 0s to separate regions.
 */

#include <assert.h>
#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "ll.h"
#include "vector.h"

/* If you have more than (MAX_CHROM_SIZE*4)*2 bytes of RAM
 * in your system, this option will speed up the program.
 * If you do not define BIG_MEMORY, the MAX_CHROM_SIZE
 * file buffer will be trimmed down to an appropriate size.
 */
#define BIG_MEMORY 1

#define KB *1000
#define MB *1000 KB
#define MAX_CHROM_SIZE  500 MB


double t_score;
double n_score;

typedef struct island {
	int start;
	int end;
	int maxend;
	int tcount;
	int ncount;
	double score;
	double maxscore;
	struct island *prev;
	struct island *next;
} ISLAND;

/*
 * Limits the size of each chromosome to MAX_CHROM_SIZE.
 * This allows us to get a list of sorted reads in O(n)
 * time but requires a fairly large amount of memory.
 */
VECTOR *
readfile(const char *fname, int *reads)
{
	VECTOR *X, *Y;
	int i, oob_reads, pos, maxpos;
	FILE *f;

	X = vector(MAX_CHROM_SIZE);

	f = fopen(fname, "r");
	if (f == NULL)
		err(1, "readfile: fopen(%s)", fname);

	//printf("V: Reading file %s...\n", fname);
	*reads = 0;
	oob_reads = 0;
	maxpos = -1;
	while (!feof(f)) {
		if (fscanf(f, "%d", &pos) < 1)
			break;
		if (pos < 0 && pos >= MAX_CHROM_SIZE)
			++oob_reads;
		else {
			++INDEX(X, pos);
			++*reads;
			maxpos = maxpos < pos ? pos : maxpos;
		}
	}

	//printf("V: %d reads found in the range [0, %d]\n", *reads, maxpos);
	if (oob_reads > 0) {
		printf("Discarded %d out of bounds reads (max allowed posn: %d)\n",
			oob_reads, MAX_CHROM_SIZE);
	}

#ifndef BIG_MEMORY
	/* Return a copy of X trimmed down to the maximum observed pos */
	Y = vector(maxpos + 1);
	for (i = 0; i < length(Y); ++i)
		INDEX(Y, i) = INDEX(X, i);
	freev(X);
	return Y;
#else
	/* Just fake the shorter length, don't change the memory */
	//printf("V: trimming length from %d to %d\n", length(X), maxpos);
	length(X) = maxpos;  
	return X;
#endif
}

void
clear_island(ISLAND *i)
{
	i->start = 0;
	i->end = 0;
	i->maxend = 0;
	i->tcount = 0;
	i->ncount = 0;
	i->score = 0;
	i->maxscore = 0;
	i->prev = NULL;
	i->next = NULL;
}

ISLAND *
copy_island(ISLAND *i)
{
	ISLAND *x;
	x = malloc(sizeof(ISLAND));
	if (x == NULL)
		err(1, "copy_island: malloc");

	x->start = i->start;
	x->end = i->end;
	x->maxend = i->maxend;
	x->tcount = i->tcount;
	x->ncount = i->ncount;
	x->score = i->score;
	x->maxscore = i->maxscore;
	x->prev = i->prev;
	x->next = i->next;

	return x;
}

void
print_island(const char *type, ISLAND *i, double p)
{
	double audic(int t, int n, double p);

	printf("%s\t%d\t%d\t%d\t%d\t%0.2lf\t%0.4le\n",
		type, i->start, i->maxend, i->tcount, i->ncount, i->maxscore,
		audic(i->tcount, i->ncount, p));
}

typedef LL(ISLAND) ilist;

/*
 * Determines the highest scoring (by Smith-Waterman) island
 * contained in the island 'area'.
 */
ilist
sw(int level, VECTOR *T, VECTOR *N, ISLAND area,
	double threshold, int score_cutoff) // , int base_score)
{
	int i;
	double t_score_local, n_score_local;
	double change;
	double total;
	ISLAND I, maxI;
	ilist results = ll_new();

	assert(length(T) == length(N));

	/* Get normalized/thresholded scores for each read type */
	//total = area.tcount + area.ncount;
	//t_score = base_score * (double)area.ncount / total;
	t_score_local = t_score - threshold;
	//n_score = -base_score * (double)area.tcount / total;
	n_score_local = n_score - threshold;

	clear_island(&I);
	clear_island(&maxI);
	maxI.score = -1;

	for (i = area.start; i < area.end; ++i) {
		change = INDEX(T, i) * t_score_local +
			INDEX(N, i) * n_score_local;

		if (I.score + change > 0) {
			I.score += change;
			I.tcount += INDEX(T, i);
			I.ncount += INDEX(N, i);
		} else {
			if (maxI.score > score_cutoff) {
				I.maxscore = maxI.score;
				I.maxend = maxI.end;
				I.tcount = maxI.tcount;
				I.ncount = maxI.ncount;
				ll_append(results, copy_island(&I));
			}
			clear_island(&I);
			clear_island(&maxI);
			I.start = i;
		}

		if (I.score > maxI.score) {
			I.end = i;
			maxI = I;
		}
	}

	return results;
}

/*
 * NOTES:
 *   - 'type' should be "gain" or "loss".
 *   - 'threshold' is a penalty applied to every read
 *     (both tumor and normal) to cause the expected sum
 *     of many read positions to be negative.  This is
 *     necessary for Smith-Waterman searching.
 *   - +base_score is given to tumor reads; -base_score
 *     is assigned to normal reads.  These values are
 *     pre-thresholding *and* pre-normalization.
 */
void
sw_seq(VECTOR *T, int ntumor, VECTOR *N, int nnormal, const char *type,
	double threshold, double score_cutoff, double p) // , int base_score)
{
	int i;
	ISLAND whole_chromosome;
	ilist islands;

	assert(length(T) == length(N));

	/* A fake island that contains the entire chromosome */
	/* Simplifies the sw() interface. */
	whole_chromosome.start = 0;
	whole_chromosome.end = length(T);  /* Equiv to length(N) */
	whole_chromosome.tcount = ntumor;
	whole_chromosome.ncount = nnormal;

	/* Get the list of islands above the score cutoff */
	islands = sw(1, T, N, whole_chromosome,
		threshold, score_cutoff);  // , base_score);

	/* To be clear: we don't expect many islands here.  The
	 * following code is O(length(islands)^2) because there's
	 * no need for an O(n lg n) implementation.  To be clear:
	 * it's easily doable.  */
	ISLAND *x, *y;
	ilist xs;
	while (ll_length(islands) > 0) {
		/* Finding max ~ O(n^2) sort. Improve if needed */
		x = ll_head(islands);
		for (y = ll_head(islands); y != NULL; y = ll_next(y))
			if (y->maxscore > x->maxscore)
				x = y;

		print_island(type, x, p);

		ll_delete(islands, x);  /* Removes x from the list */

		/* Remove reads in this island */
		for (i = x->start; i < x->end; ++i) {
			INDEX(T, i) = 0;
			INDEX(N, i) = 0;
		}

		/* Run sw-seq on the remaining island to determine
		 * if any subset of x should be re-inserted into
		 * the island list. */
		/* NOTE: we sort by max SW-score.  This should only
		 * decrease as additional islands are found. */
		xs = sw(1, T, N, *x,
			threshold, score_cutoff);  // , base_score);
		//printf("V: %d islands discovered within island\n",
			//ll_length(xs));
		for (y = ll_head(xs); y != NULL; y = ll_next(y))
			ll_append(islands, y);

		free(x);
	}
}

int
main(int argc, char **argv)
{
	int diff;
	VECTOR *T, *N;
	int ntumor, nnormal;
	int total_t, total_n;
	int cutoff;
	double gain_thresh, loss_thresh;

	if (argc < 3 || argc > 6)
		errx(1, "usage: %s <tumor file> <normal file> [total tumor reads] [total normal reads] [SW-score cutoff]", argv[0]);

	T = readfile(argv[1], &ntumor);
	N = readfile(argv[2], &nnormal);

	/* Default values */
	total_t = total_n = 1;
	cutoff = 80;

	/* Optional command line arguments */
	if (argc > 3)
		total_t = strtol(argv[3], NULL, 10);
	if (argc > 4)
		total_n = strtol(argv[4], NULL, 10);
	if (argc > 5)
		cutoff = strtol(argv[5], NULL, 10);

	t_score = 2.0 *total_n / (total_t + total_n);
	n_score = -2.0 *total_t / (total_t + total_n);

	gain_thresh = (3*t_score + 2*n_score) / 10;
	loss_thresh = -(t_score + 2*n_score) / 6;

	printf("Using Smith-Waterman score cutoff: %d\n", cutoff);
	printf("Total tumor reads: %d, total normal reads: %d\n",
		total_t, total_n);
	printf("Calculated gain threshold: %f, loss threshold: %f\n",
		gain_thresh, loss_thresh);


	/* Extend the shorter vector to match the longer one.  Fill with 0s */
	diff = abs(length(T) - length(N));
	if (length(T) > length(N))
		N = extendv_noalign(N, diff);
	else 
		T = extendv_noalign(T, diff);

	/* Use below for simulated data. */
	sw_seq(T, ntumor, N, nnormal, "gain", gain_thresh, cutoff,
		(double)ntumor / (double)(ntumor + nnormal)); // , 2);
	sw_seq(N, nnormal, T, ntumor, "loss", loss_thresh, cutoff,
		(double)nnormal / (double)(ntumor + nnormal)); // , 2);

	freev(T);
	freev(N);

	return 0;
}
