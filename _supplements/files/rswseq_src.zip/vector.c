/* Simple, minimalistic implementation of integer vectors */

#include <err.h>
#include <math.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "vector.h"

#define MIN(a, b) ((a) < (b) ? (a) : (b))

/* Just a uniformly distributed random integer in [a,b] */
int
number(int a, int b)
{
	int x;

	if (a > b) {
		x = a;
		a = b;
		b = x;
	}

	return a + (random() % (b - a + 1));
}

VECTOR *
vector(int n)
{
	int x;
	int stride;
	VECTOR *v;

	v = malloc(sizeof(VECTOR));
	if (v == NULL)
		err(1, "vector: malloc");

	stride = n;

	/* If stride isn't a multiple of the packing format, make it one */
	if (stride % PACKED_INTS != 0)
		stride += PACKED_INTS - (n % PACKED_INTS);

	/* Get aligned memory for SSE */
	x = posix_memalign((void *)&v->data, INT_ALIGNMENT, stride*sizeof(int));
	if (x != 0)
		errx(1, "vector: calloc: %s\n", strerror(x));

	v->stride = stride;
	v->cols = n;
	v->rows = 1;

	clearv(v);

	return v;
}

void
freev(VECTOR *v)
{
	free(v->data);
	free(v);
}

/*
 * Make a matrix with the specified rows and columns.
 * Additionally, each row of the matrix is aligned to INT_ALIGNMENT.
 * A matrix cannot be traversed over like a flat array, due to the
 * row alignment.  Thus, the ->length attribute is the number of
 * columns INCLUDING alignment.
 *
 * XXX: Clean up this alignment stuff.  It's TERRIBLE.
 */
VECTOR *
matrix(int rows, int cols)
{
	int x;
	int stride;
	VECTOR *m;

	m = malloc(sizeof(VECTOR));
	if (m == NULL)
		err(1, "matrix: malloc");

	/* Make stride a multiple of the packing length */
	stride = cols;
	if (stride % PACKED_INTS != 0)
		stride += PACKED_INTS - (stride % PACKED_INTS);

	x = posix_memalign((void *) &m->data, INT_ALIGNMENT,
	                   stride*rows * sizeof(int));
	if (x != 0)
		errx(1, "matrix: posix_memalign: %s\n", strerror(x));

	m->stride = stride;
	m->rows = rows;
	m->cols = cols;

	clearv(m);

	return m;
}

/* Extend the vector v WITHOUT aligning for SSE.  Fill with 0s. */
VECTOR *
extendv_noalign(VECTOR *v, int cols)
{
	int i;

	v->cols += cols;
	v->data = realloc(v->data, v->cols*sizeof(int));
	if (v->data == NULL)
		err(1, "extend_noalign: realloc");

	/* Fill with 0s */
	for (i = v->cols - cols; i < v->cols; ++i)
		INDEX(v, i) = 0;

	return v;
}

/* Extend the number of rows in the matrix M.  Preserves alignment. */
VECTOR *
extendmr(VECTOR *M, int n)
{
	VECTOR *M2;

	M2 = matrix(M->rows + n, M->cols);

	clearv(M2);

	memcpy(M2->data, M->data, M->stride*M->rows*sizeof(int));

	freev(M);

	return M2;
}

/* Chop M so that it has only n rows */
VECTOR *
chopmr(VECTOR *M, int n)
{
	if (n > M->rows)
		errx(1, "chopmr: M has %d rows, asked to chop to %d rows\n",
		     M->rows, n);

	/* Pretty simple really */
	M->rows = n;

	return M;
}

/* Swap rows a and b */
VECTOR *
swapmr(VECTOR *M, int a, int b)
{
	int row_size;
	VECTOR *T;

	row_size = M->stride * sizeof(int);

	T = vector(M->stride);

	memcpy(T->data, ROW(M, a), row_size);
	memcpy(ROW(M, a), ROW(M, b), row_size);
	memcpy(ROW(M, b), T->data, row_size);

	freev(T);

	return M;
}

/* Zero out the vector */
void
clearv(VECTOR *v)
{
	memset(v->data, 0, v->rows * v->stride * sizeof(int));
}

void
fprintv(FILE *f, VECTOR *v)
{
	int i, j;
	int x;

	for (i = 0; i < v->rows; ++i) {
		x = i * v->stride;    /* The row, accounting for alignment */
		for (j = 0; j < v->cols; ++j) {
			if (v->data[x + j] != INF)
				fprintf(f, "%d ", v->data[x + j]);
			else
				fprintf(f, "INF ");
		}
		fprintf(f, "\n");
	}
}

void
printv(char *name, VECTOR *v)
{
	if (v->rows > 1)
		printf("%s(%d,%d):\n", name, v->rows, v->cols);
	else
		printf("%s(%d): ", name, v->cols);

	fprintv(stdout, v);
}

/* Quick and easy binary storage */
void
storem(char *filename, VECTOR *V)
{
	FILE *f;

	f = fopen(filename, "wb");
	if (f == NULL)
		err(1, "storev: couldn't open file %s", filename);

	fwrite(V, sizeof(VECTOR), 1, f);
	fwrite(V->data, sizeof(int), V->rows*V->stride, f);

	fclose(f);
}

VECTOR *
loadm(char *filename)
{
	FILE *f;
	VECTOR *V, T;

	f = fopen(filename, "rb");
	if (f == NULL)
		err(1, "loadv: couldn't open file %s", filename);

	/* Read into a temporary vector to store results */
	fread(&T, sizeof(VECTOR), 1, f);

	V = matrix(T.rows, T.cols);
	fread(V->data, sizeof(int), V->rows*V->stride, f);

	fclose(f);

	return V;
}

/* a = a + b */
void
addv(VECTOR *a, VECTOR *b)
{
	int i;

	for (i = 0; i < a->cols; ++i)
		INDEX(a, i) += INDEX(b, i);
}

int
maxv(VECTOR *v)
{
	int i, j, m;
	int offset;

	m = -INF;
	for (i = 0; i < v->rows; ++i) {
		offset = i * v->stride;
		for (j = 0; j < v->cols; ++j)
			if (v->data[offset + j] > m)
				m = v->data[offset + j];
	}

	return m;
}

/* Set each element in the tail to k.
 * Vectors come with a stride that is guaranteed to be a multiple
 * of 4, even if the vector requires less space.  Thus, there is
 * an unused tail of between 0-3 integers at the end of V that
 * need to be dealt with, or else their values may influence the
 * min calculation.
 *
 * The unused values are guaranteed to always have a value of 0.
 * So we set them each to INF here, then back to 0 before we
 * return to ensure this condition holds for later functions.
 */
void
mod_tail(VECTOR *V, int k)
{
	int len;
	int *tail;

	if (V->cols % PACKED_INTS != 0) {
		tail = V->data + V->cols;

		if (V->cols % PACKED_INTS != 0)
			len = PACKED_INTS - (V->cols % PACKED_INTS);
		switch (len) {
		case 3:
			tail[2] = k;
		case 2:
			tail[1] = k;
		case 1:
			tail[0] = k;
		default:
			break;
		}
	}
}

/*
 * Have 4 parallel mins running throughout.  At the end, do one
 * sequential min to get the real min.
 *
int
minv_fast(VECTOR *V)
{
	int i, end;
	v4si *v;
	v4si min = { INF, INF, INF, INF };
	int *m;

	mod_tail(V, INF);

	v = V->data;
	end = V->stride / sizeof(int);

	for (i = 0; i < end; ++i)
		min = __builtin_ia32_pminsd128(v[i], min);

	m = &min;
	m[0] = MIN(m[0], m[1]);
	m[0] = MIN(m[0], m[2]);
	m[0] = MIN(m[0], m[3]);

	mod_tail(V, 0);

	return m[0];
}
*/

int
minv(VECTOR *v)
{
	int i, j, m;
	int offset;

	m = INF;
	for (i = 0; i < v->rows; ++i) {
		offset = i * v->stride;
		for (j = 0; j < v->cols; ++j)
			if (v->data[offset + j] < m)
				m = v->data[offset + j];
	}

	return m;
}

/* Return the list of indices in v s.t. v[i] = k */
/* Not intended for matrices */
/* This appears to be unvectorizable: it makes sense, because
 * each comparison's destination depends on whether the previous
 * comparisons succeeded or failed. */
VECTOR *
whichv(VECTOR *v, int k)
{
	int i, j;
	VECTOR *w;

	w = vector(v->cols); /* The result can be at most the size of v */
	for (i = 0, j = 0; i < v->cols; ++i)
		if (v->data[i] == k)
			w->data[j++] = i;

	/* Messy, but better than copying the data into a new vector */
	w->cols = j;
	if (j % PACKED_INTS == 0)
		w->stride = j;
	else
		w->stride = j + (j % PACKED_INTS);

	return w;
}

/* Return the slice A[B], where A has length a and B has length b */
/* A slice is the sub-array of A corresponding to indexes in B. */
/* Not intended to work with matrices */
VECTOR *
slicev(VECTOR *v, VECTOR *w)
{
	int i;
	VECTOR *s;

	s = vector(w->cols);
	for (i = 0; i < w->cols; ++i)
		s->data[i] = v->data[w->data[i]];

	return s;
}
