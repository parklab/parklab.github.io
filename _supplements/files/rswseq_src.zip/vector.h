#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <limits.h>
#include "sse.h"

#define INT_ALIGNMENT 16
#define PACKED_INTS    4

#define INF INT_MAX

#define INDEX(_v, _i)  ((_v)->data[(_i)])
#define ROW(_M, _r)    ((_M)->data + (_r)*(_M)->stride)
#define length(_v)     ((_v)->cols)

#define VECTOR struct vector
struct vector {
	int *data;
	int stride;
	int rows;
	int cols;
};

VECTOR *vector(int length);
VECTOR *matrix(int rows, int cols);
VECTOR *extendv_noalign(VECTOR *v, int n);
void clearv(VECTOR *v);
void printv(char *name, VECTOR *v);
void freev(VECTOR *v);
int maxv(VECTOR *v);
VECTOR *swapmr(VECTOR *M, int row1, int row2);
VECTOR *chopmr(VECTOR *M, int length);
VECTOR *loadm(char *filepath);

#endif /* __VECTOR_H__ */
